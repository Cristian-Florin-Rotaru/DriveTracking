<?php
//https://speedtracker.000webhostapp.com/userLog.php?argument1=
//PHP Script for getting the information about the incidents a specific driver had, (the argument provided is expected to be the username)

require "dbConnect.php";
$gMapsURL = "https://www.google.com/maps/@";
$argument1 = $_GET['argument1'];

//Query to get the information about where and when a specific user surpassed the speed limit
$limitPassedSql = "select * from LimitPassed WHERE UserID = 
				(Select UserID FROM Users WHERE UserName LIKE '$argument1')
				ORDER BY Time DESC;";
$limitPassedT = mysqli_query($conn, $limitPassedSql);;


echo "<p></p><strong>Limit Passed Table</strong></p>";
//If any information was found with the previous query, builds a HTML table with the data found on database to be showed
if ($limitPassedT->num_rows > 0) {
    echo "<table border = \"1\"><tr><th>Speed</th><th>SpeedLimit</th></th>
		<th>Time</th><th>Latitude</th><th>Longitude</th><th>Google Maps</th></tr>";
    // output data of each row
    while($row = $limitPassedT->fetch_assoc()) {
        echo "<tr><td>".$row["Speed"]."</td><td>".$row["SpeedLimit"]."</td><td>".$row["Time"]."</td>
			<td>".$row["Latitude"]."</td><td>".$row["Longitude"]."</td>
			<td><a href=\"".$gMapsURL.$row["Latitude"].",".$row["Longitude"].",19z\" target=\"_blank\">See on map</a></td></tr>";
    }
    echo "</table>";
} else {
    echo "No records";
}
//Query to get the information about where and when a specific user performed a Harsh Acceleration
$aggroAccelSql = "select * from AggroAccel WHERE UserID = (Select UserID FROM Users WHERE UserName LIKE '$argument1') ORDER BY Time DESC;";/*(Select UserID FROM Users WHERE UserName LIKE '". ."');";*/
$aggroAccelT = mysqli_query($conn, $aggroAccelSql);


echo "<p></p><p></p><p><strong>Aggressive Acceleration Table</strong></p>";
//If any information was found with the previous query, builds a HTML table with the data found on database to be showed
if ($aggroAccelT->num_rows > 0) {
    echo "<table border = \"1\"><tr><th>Time</th><th>Latitude</th><th>Longitude</th><th>Google Maps</th></tr>";
    // output data of each row
    while($row = $aggroAccelT->fetch_assoc()) {
        echo "<tr><td>".$row["Time"]."</td><td>".$row["Latitude"]."</td><td>".$row["Longitude"]."</td><td><a href=\"".$gMapsURL.$row["Latitude"].",".$row["Longitude"].",19z\" target=\"_blank\">See on map</a></td></tr>";
    }
    echo "</table>";
} else {
    echo "No records";
}
//Query to get the information about where and when a specific user performed a Harsh Brake
$aggroBrakeSql = "select * from AggroBrake WHERE UserID = (Select UserID FROM Users WHERE UserName LIKE '$argument1') ORDER BY Time DESC;";/*(Select UserID FROM Users WHERE UserName LIKE '". ."');";*/
$aggroBrakeT = mysqli_query($conn, $aggroBrakeSql);

echo "<p></p><p></p><p><strong>Aggressive Brakes Table</strong></p>";
//If any information was found with the previous query, builds a HTML table with the data found on database to be showed
if ($aggroBrakeT->num_rows > 0) {
    echo "<table border = \"1\"><tr><th>Time</th><th>Latitude</th><th>Longitude</th><th>Google Maps</th></tr>";
    // output data of each row
    while($row = $aggroBrakeT->fetch_assoc()) {
        echo "<tr><td>".$row["Time"]."</td><td>".$row["Latitude"]."</td><td>".$row["Longitude"]."</td><td><a href=\"".$gMapsURL.$row["Latitude"].",".$row["Longitude"].",19z\" target=\"_blank\">See on map</a></td></tr>";
    }
    echo "</table>";
} else {
    echo "No records";
}

$conn->close();
?>

