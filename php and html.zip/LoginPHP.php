<?php
//LoginPHP.php Helps with checking if the entered username and password correspond to any account
require "dbConnect.php";
//https://speedtracker.000webhostapp.com/LoginPHP.php
$user_name = $_POST["user_name"]; 	//Expected String
$user_pass = $_POST["password"]; 	//Expected String

$sql = "SELECT * FROM Users where UserName like '$user_name' and Password like '$user_pass';";
$result = mysqli_query($conn ,$sql);
if ($result->num_rows > 0) {
	$row = $result->fetch_assoc();
	echo $row['UserID'];
}
else {
	 echo "Reject";
 }