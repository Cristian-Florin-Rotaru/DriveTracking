<?php
//https://speedtracker.000webhostapp.com/AggroAccelLog.php?user=A&lat=B&long=C
//PHP Script to log into database information about aggressive acceleration
require "dbConnect.php";
$argUser = $_POST["user"]; //Expected int number (UserID)
$argLat = $_POST["lat"]; 	// Expected String
$argLong = $_POST["long"];	// Expected String

// Query used to add to database the details about Where and When an aggressive acceleration was registered 
$sql = "INSERT INTO AggroAccel(UserID, Latitude, Longitude) VALUES ($argUser, '$argLat', '$argLong');"; 
$result = mysqli_query($conn, $sql);
// Query to check if the previous details were correctly sent to database
$sql = "SELECT * FROM AggroAccel WHERE UserID= $argUser AND Latitude LIKE '$argLat' AND Longitude LIKE '$argLong';";

$result = mysqli_query($conn, $sql);

//After the INSERT query is completed, it checks if the information was inserted successfully
if ($result->num_rows > 0) {
	echo "yes";
}
else {
	 echo "no";
 }


$conn->close();
?>

