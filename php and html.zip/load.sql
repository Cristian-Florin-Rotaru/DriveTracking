create table Users (
	UserID int NOT NULL AUTO_INCREMENT,
	LastName varchar(255) NOT NULL,
	FirstName varchar(255) NOT NULL,
	UserName varchar(255) NOT NULL UNIQUE,
	Password varchar(255) NOT NULL,
	PRIMARY KEY (UserID)
	);

create table LimitPassed (
	ID int NOT NULL AUTO_INCREMENT,
	UserID int NOT NULL,
	Speed varchar(255) NOT NULL,
	SpeedLimit varchar(255) NOT NULL,
	Time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	Latitude varchar(255) NOT NULL,
	Longitude varchar(255) NOT NULL,
	PRIMARY KEY (ID),
	FOREIGN KEY (UserID) REFERENCES Users(UserID)
	);
	
create table AggroAccel (
	ID int NOT NULL AUTO_INCREMENT,
	UserID int NOT NULL,
	Time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	Latitude varchar(255) NOT NULL,
	Longitude varchar(255) NOT NULL,
	PRIMARY KEY (ID),
	FOREIGN KEY (UserID) REFERENCES Users(UserID)
	);

	create table AggroBrake (
	ID int NOT NULL AUTO_INCREMENT,
	UserID int NOT NULL,
	Time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	Latitude varchar(255) NOT NULL,
	Longitude varchar(255) NOT NULL,
	PRIMARY KEY (ID),
	FOREIGN KEY (UserID) REFERENCES Users(UserID)
	);
