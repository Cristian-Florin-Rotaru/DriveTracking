<?php
//https://speedtracker.000webhostapp.com/SpeedLimitLog.php?user=A&speed=B&limit=C&lat=D&long=E
//PHP Script to log into database information about surpassing the speed limit
require "dbConnect.php";
$argUser = $_POST["user"]; //Expected int number (UserID)
$argSpeed = $_POST["speed"]; // Expected String
$argLimit = $_POST["limit"]; // Expected String
$argLat = $_POST["lat"]; 	// Expected String
$argLong = $_POST["long"];	// Expected String

// Query used to add to database the details about Where and When The speed limit was surpassed 
$sql = "INSERT INTO LimitPassed(UserID, Speed, SpeedLimit, Latitude, Longitude) VALUES ($argUser, '$argSpeed', '$argLimit', '$argLat', '$argLong');"; 
$result = mysqli_query($conn, $sql);
// Query to check if the previous details were correctly sent to database

$sql = "SELECT * FROM LimitPassed WHERE UserID=$argUser AND Speed LIKE '$argSpeed' AND SpeedLimit LIKE '$argLimit' AND Latitude LIKE '$argLat' AND Longitude LIKE '$argLong';";

$result = mysqli_query($conn, $sql);

//After the INSERT query is completed, it checks if the information was inserted successfully
if ($result->num_rows > 0) {
	echo "yes";
}
else {
	 echo "no";
 }


$conn->close();
?>

