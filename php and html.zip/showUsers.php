<?php
//https://speedtracker.000webhostapp.com/showUsers.php
require "dbConnect.php";
$phpUrl = "https://speedtracker.000webhostapp.com/userLog.php?argument1=";

//Query to get the information about all the users
$sql = "SELECT UserName, Password, FirstName, LastName FROM Users";
$result = mysqli_query($conn, $sql);

echo "<p><strong>List Of Users</strong></p>";
//If any information was found with the previous query, builds a HTML table with the data found on database to be showed
if ($result->num_rows > 0) {
    echo "<table border = \"1\"><tr><th>UserName</th><th>Password</th><th>Name</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td><a href=\"".$phpUrl.$row["UserName"]."\">".$row["UserName"]."</a></td>
		<td>".$row["Password"]."</td><td>".$row["FirstName"]." ".$row["LastName"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "No records";
}

?>